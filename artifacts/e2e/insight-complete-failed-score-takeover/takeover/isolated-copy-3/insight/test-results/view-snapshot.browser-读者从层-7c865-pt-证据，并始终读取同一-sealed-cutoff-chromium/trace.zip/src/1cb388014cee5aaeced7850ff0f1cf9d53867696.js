import { mkdirSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { isAbsolute, join, normalize, relative, resolve, sep } from "node:path";
import { withProjectCopy } from "./project-copy.js";
import { runProcess } from "./process.js";
import { ProcessHandle, startProcess } from "./process-lifecycle.js";
const INVOCATION_ID_ENV = "NICEEVAL_E2E_INVOCATION_ID";
const STAGING_ROOT_ENV = "NICEEVAL_E2E_ARTIFACT_STAGING_ROOT";
function safeSegment(value, label) {
    if (!/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(value) ||
        /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i.test(value)) {
        throw new Error(`${label} must be one safe path segment`);
    }
    return value;
}
function isContained(root, candidate) {
    const rel = relative(root, candidate);
    return rel === "" || (!isAbsolute(rel) && rel !== ".." && !rel.startsWith(`..${sep}`));
}
function relativeCaseTarget(value) {
    if (value.length === 0 || isAbsolute(value) || value.includes("\\") || value.includes("\0")) {
        throw new Error("artifact target must be a non-empty canonical relative path");
    }
    const canonical = normalize(value);
    if (canonical !== value ||
        canonical === "." ||
        canonical === ".." ||
        canonical.startsWith(`..${sep}`)) {
        throw new Error("artifact target must stay within the case namespace");
    }
    return canonical;
}
function invocationIdentity(sourceRoot) {
    const invocationId = process.env[INVOCATION_ID_ENV];
    const injectedRoot = process.env[STAGING_ROOT_ENV];
    if ((invocationId === undefined) !== (injectedRoot === undefined)) {
        throw new Error(`${INVOCATION_ID_ENV} and ${STAGING_ROOT_ENV} must be injected together`);
    }
    if (invocationId !== undefined && injectedRoot !== undefined) {
        const stagingRoot = resolve(injectedRoot);
        if (!isAbsolute(injectedRoot) || !isContained(sourceRoot, stagingRoot) || stagingRoot === sourceRoot) {
            throw new Error(`${STAGING_ROOT_ENV} must be an absolute child of the isolated source root`);
        }
        mkdirSync(stagingRoot, { recursive: true });
        return {
            invocationId: safeSegment(invocationId, INVOCATION_ID_ENV),
            stagingRoot,
            formal: true,
        };
    }
    return {
        invocationId: `local-${process.pid}`,
        stagingRoot: mkdtempSync(join(tmpdir(), "niceeval-e2e-artifacts-")),
        formal: false,
    };
}
function flattenErrors(error) {
    if (error instanceof AggregateError) {
        return [...error.errors].flatMap(flattenErrors);
    }
    return [error];
}
function throwFlattened(error) {
    const errors = flattenErrors(error);
    if (errors.length === 1)
        throw errors[0];
    throw new AggregateError(errors, "E2E case body, process cleanup, artifact staging, and project cleanup failed", {
        cause: errors[0],
    });
}
function append(prefix, args) {
    return [...prefix, ...args];
}
export function createE2EContext(options) {
    const repoId = options.repoId.trim();
    if (repoId.length === 0)
        throw new Error("repoId must be non-empty");
    const sourceRoot = resolve(options.sourceRoot ?? options.project.from);
    const invocation = invocationIdentity(sourceRoot);
    const identity = Object.freeze({
        repoId,
        sourceRoot,
        invocationId: invocation.invocationId,
        artifactStagingRoot: invocation.stagingRoot,
        formalInvocation: invocation.formal,
    });
    async function runCase(caseIdValue, caseOptions, body) {
        const caseId = safeSegment(caseIdValue, "caseId");
        const artifactRoot = join(invocation.stagingRoot, invocation.invocationId, caseId);
        const entries = (caseOptions.artifacts ?? []).map((entry) => ({
            ...entry,
            target: join(invocation.invocationId, caseId, relativeCaseTarget(entry.target)),
        }));
        const staging = entries.length === 0
            ? undefined
            : {
                stageArtifacts: {
                    destinationRoot: invocation.stagingRoot,
                    entries,
                    collision: "error",
                },
            };
        try {
            return await withProjectCopy(options.project, async ({ root: projectRoot }) => {
                const handles = [];
                const caseEnvironment = {
                    NICEEVAL_HOME: join(projectRoot, ".niceeval-user"),
                };
                const start = (argv, startOptions = {}) => {
                    const handle = startProcess(argv, {
                        ...startOptions,
                        env: { ...caseEnvironment, ...startOptions.env },
                        cwd: projectRoot,
                        processGroup: true,
                    });
                    void handle.done.catch(() => { });
                    handles.push(handle);
                    return handle;
                };
                const commands = Object.fromEntries(Object.entries(options.commands).map(([name, prefix]) => [
                    name,
                    {
                        run: (args, runOptions) => runProcess(append(prefix, args), {
                            ...runOptions,
                            env: { ...caseEnvironment, ...runOptions?.env },
                            cwd: projectRoot,
                        }),
                        start: (args, startOptions) => start(append(prefix, args), startOptions),
                    },
                ]));
                const context = {
                    paths: Object.freeze({ sourceRoot, projectRoot, artifactRoot }),
                    commands,
                    run: (argv, runOptions) => runProcess(argv, {
                        ...runOptions,
                        env: { ...caseEnvironment, ...runOptions?.env },
                        cwd: projectRoot,
                    }),
                    start,
                };
                let result;
                let bodyFailed = false;
                let bodyError;
                try {
                    result = await body(context);
                }
                catch (error) {
                    bodyFailed = true;
                    bodyError = error;
                }
                const cleanupErrors = [];
                for (const handle of handles.reverse()) {
                    try {
                        await handle.dispose();
                    }
                    catch (error) {
                        cleanupErrors.push(error);
                    }
                }
                const errors = bodyFailed ? [bodyError, ...cleanupErrors] : cleanupErrors;
                if (errors.length === 1)
                    throw errors[0];
                if (errors.length > 1) {
                    throw new AggregateError(errors, "E2E case body and process cleanup failed", {
                        cause: errors[0],
                    });
                }
                return result;
            }, staging);
        }
        catch (error) {
            throwFlattened(error);
        }
    }
    return {
        identity,
        case(caseId, optionsOrBody, maybeBody) {
            const caseOptions = typeof optionsOrBody === "function" ? {} : optionsOrBody;
            const body = typeof optionsOrBody === "function" ? optionsOrBody : maybeBody;
            if (body === undefined)
                throw new Error("E2E case body is required");
            return runCase(caseId, caseOptions, body);
        },
    };
}

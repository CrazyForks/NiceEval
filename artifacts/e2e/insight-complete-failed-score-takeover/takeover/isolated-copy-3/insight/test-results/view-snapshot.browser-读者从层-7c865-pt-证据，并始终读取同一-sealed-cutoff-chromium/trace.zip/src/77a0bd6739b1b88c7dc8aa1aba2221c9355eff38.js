import { cp, mkdir, mkdtemp, rm, symlink } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, isAbsolute, join, relative, resolve, sep, } from "node:path";
import { stageArtifacts } from "./artifact-staging.js";
function assertLinkInsideRoot(root, to) {
    if (to.length === 0) {
        throw new Error("link destination must be a non-empty relative path");
    }
    if (isAbsolute(to)) {
        throw new Error(`link destination must be relative to project root: ${to}`);
    }
    const dest = resolve(root, to);
    const rel = relative(root, dest);
    if (rel === "" || rel.startsWith(`..${sep}`) || rel === ".." || isAbsolute(rel)) {
        throw new Error(`link destination escapes project root: ${to}`);
    }
    return dest;
}
async function removeCopy(root) {
    await rm(root, { recursive: true, force: true });
}
async function materializeCopy(options) {
    const source = resolve(options.from);
    const root = await mkdtemp(join(tmpdir(), options.prefix));
    const omit = new Set(options.omitTopLevel ?? []);
    try {
        await cp(source, root, {
            recursive: true,
            filter: (src) => {
                const rel = relative(source, src);
                if (rel === "" || rel === ".") {
                    return true;
                }
                const top = rel.split(sep)[0] ?? rel;
                return !omit.has(top);
            },
        });
        for (const link of options.links ?? []) {
            const dest = assertLinkInsideRoot(root, link.to);
            await mkdir(dirname(dest), { recursive: true });
            const linkType = link.type ?? "file";
            await symlink(link.from, dest, linkType);
        }
        return root;
    }
    catch (error) {
        try {
            await removeCopy(root);
        }
        catch (cleanupError) {
            throw new AggregateError([error, cleanupError], "project copy setup and cleanup failed", {
                cause: error,
            });
        }
        throw error;
    }
}
/**
 * Byte-copy a project tree into a unique temp directory, optionally omitting
 * top-level names and creating in-copy links. Always deletes the copy after
 * the body returns or throws (including setup/link failures).
 */
export async function withProjectCopy(options, body, staging) {
    const root = await materializeCopy(options);
    let bodyError;
    let result;
    let bodyFailed = false;
    let stagingError;
    let stagingFailed = false;
    let cleanupError;
    let cleanupFailed = false;
    try {
        result = await body({ root });
    }
    catch (error) {
        bodyFailed = true;
        bodyError = error;
    }
    try {
        if (staging !== undefined) {
            await stageArtifacts({
                sourceRoot: root,
                destinationRoot: staging.stageArtifacts.destinationRoot,
                entries: staging.stageArtifacts.entries,
                collision: staging.stageArtifacts.collision,
            });
        }
    }
    catch (error) {
        stagingFailed = true;
        stagingError = error;
    }
    try {
        await removeCopy(root);
    }
    catch (error) {
        cleanupFailed = true;
        cleanupError = error;
    }
    const errors = [];
    if (bodyFailed)
        errors.push(bodyError);
    if (stagingFailed)
        errors.push(stagingError);
    if (cleanupFailed)
        errors.push(cleanupError);
    if (errors.length === 1)
        throw errors[0];
    if (errors.length > 1) {
        throw new AggregateError(errors, "project copy body, artifact staging, and cleanup failed", {
            cause: bodyFailed ? bodyError : errors[0],
        });
    }
    return result;
}

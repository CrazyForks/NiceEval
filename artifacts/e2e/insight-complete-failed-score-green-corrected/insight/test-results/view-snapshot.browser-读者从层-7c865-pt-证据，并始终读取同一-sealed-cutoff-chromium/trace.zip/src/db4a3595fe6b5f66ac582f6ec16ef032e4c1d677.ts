// rerun: pnpm e2e test --repo insight -- --run test/view-snapshot.browser.spec.ts

import { only, type ProcessHandle } from "@niceeval/testkit";
import { expect, test } from "@playwright/test";
import { writeFile } from "node:fs/promises";
import { join } from "node:path";
import {
  expectLoopbackReadyUrl,
  insightCaseArtifacts,
  insightE2E,
  waitForViewReady,
} from "./support.ts";
// @use-case docs/feature/insight/use-case/insight-review-run-adoption.md
// @regression memory/insight-aggregate-hides-partial-state.md
// @regression memory/report-header-experiment-selector-regression.md
// @regression memory/report-match-details-obscure-score-and-collection.md
// @regression memory/report-result-cell-exposes-float-noise-and-unlabeled-coverage.md
// @regression memory/view-hard-refresh-duplicates-attempt-overlay.md
// @regression memory/view-renderer-flattens-debug-evidence.md
// @regression memory/view-run-selection-is-ignored.md

test("读者从层级 Overview 在可恢复 overlay 中审阅完整 Attempt 证据，并始终读取同一 sealed cutoff", async ({ page }, testInfo) => {
  test.setTimeout(240_000);
  const pageErrors: string[] = [];
  const consoleErrors: string[] = [];
  const failedResponses: Array<{ readonly path: string; readonly status: number }> = [];
  page.on("pageerror", (error) => pageErrors.push(error.message));
  page.on("console", (message) => {
    if (message.type() === "error") consoleErrors.push(message.text());
  });
  page.on("response", (response) => {
    const url = new URL(response.url());
    if (url.hostname === "127.0.0.1" && response.status() >= 400) {
      failedResponses.push({ path: url.pathname, status: response.status() });
    }
  });

  await insightE2E.case(
    "view-snapshot-browser",
    { artifacts: insightCaseArtifacts() },
    async ({ paths: { projectRoot }, commands: { niceeval } }) => {
      const scoreRun = await niceeval.run(["exp", "score-completeness", "--rerun", "all", "--json"]);
      expect(scoreRun.exitCode, scoreRun.diagnostic()).toBe(1);
      expect(scoreRun.expReceipt(), scoreRun.diagnostic()).toMatchObject({ completion: "completed" });
      const scoreRunId = only(scoreRun.expReceipt().createdRunIds, () => true, scoreRun.diagnostic());
      const scoreEvents = scoreRun.expEvalEvents();
      const scoreLocators = new Map<string, string>();
      for (const [evalId, verdict] of [
        ["score-completeness/failed", "failed"],
        ["score-completeness/zero", "failed"],
        ["score-completeness/partial", "errored"],
        ["score-completeness/unavailable", "errored"],
      ] as const) {
        const event = only(scoreEvents, (item) => item.evalId === evalId, scoreRun.diagnostic());
        expect(event).toMatchObject({ verdict, attempts: 1 });
        scoreLocators.set(evalId, withAt(event.locator));
      }

      const scoreRequestPath = join(projectRoot, "score-completeness.request.json");
      await writeFile(scoreRequestPath, JSON.stringify({
        protocol: "niceeval.query/v1",
        operation: { kind: "run.summary", runId: scoreRunId },
      }));
      const scoreSummary = await niceeval.run(["query", "run", "--request", scoreRequestPath]);
      expect(scoreSummary.exitCode, scoreSummary.diagnostic()).toBe(0);
      const scoreMembers = scoreSummary.querySuccess("run.summary").summary.members;
      // These same public facts must survive the Overview aggregation and View.
      for (const [evalId, earned, possible] of [
        ["score-completeness/failed", 61, 100],
        ["score-completeness/zero", 0, 200],
      ] as const) {
        expect(only(scoreMembers, (member) => member.evalId === evalId, scoreSummary.diagnostic()))
          .toMatchObject({ verdict: "failed", score: { state: "complete", earned, possible } });
      }

      await writeFile(scoreRequestPath, JSON.stringify({
        protocol: "niceeval.query/v1",
        operation: { kind: "overview.get", runIds: [scoreRunId] },
      }));
      const scoreOverview = await niceeval.run(["query", "run", "--request", scoreRequestPath]);
      expect(scoreOverview.exitCode, scoreOverview.diagnostic()).toBe(0);
      const scoreOverviewDocument = scoreOverview.querySuccess("overview.get");
      for (const [evalId, earned, possible] of [
        ["score-completeness/failed", 61, 100],
        ["score-completeness/zero", 0, 200],
      ] as const) {
        const cell = only(scoreOverviewDocument.overview.cells, (item) => item.evalId === evalId, scoreOverview.diagnostic());
        expect(cell.verdict.tally).toEqual({ passed: 0, failed: 1, errored: 0, skipped: 0 });
        expect(cell.score).toMatchObject({
          state: "available", value: earned, samples: 1, total: 1, basis: "slot",
          bounds: { min: 0, max: possible },
        });
        expect(only(cell.members, () => true, scoreOverview.diagnostic()).publication).toMatchObject({
          state: "published",
          attemptLocator: scoreLocators.get(evalId),
          score: { state: "available", value: earned, samples: 1, total: 1, bounds: { min: 0, max: possible } },
        });
      }
      for (const [evalId, memberState, memberValue] of [
        ["score-completeness/partial", "partial", 9],
        ["score-completeness/unavailable", "unavailable", null],
      ] as const) {
        const cell = only(scoreOverviewDocument.overview.cells, (item) => item.evalId === evalId, scoreOverview.diagnostic());
        expect(cell.score).toMatchObject({ state: "unavailable", value: null, samples: 0, total: 1 });
        expect(only(cell.members, () => true, scoreOverview.diagnostic()).publication).toMatchObject({
          state: "published", score: { state: memberState, value: memberValue, samples: 0, total: 1 },
        });
      }
      const completeSubtotal = {
        state: "partial", value: 61, samples: 2, total: 4, basis: "eval",
        bounds: { min: 0, max: 300 },
      };
      expect(only(scoreOverviewDocument.overview.experiments, (item) => item.experimentId === "score-completeness", scoreOverview.diagnostic()).score)
        .toMatchObject(completeSubtotal);
      expect(scoreOverviewDocument.overview.totals.score).toMatchObject(completeSubtotal);

      const inspection = await niceeval.run(["exp", "main", "--rerun", "all", "--json"]);
      expect(inspection.exitCode, inspection.diagnostic()).toBe(0);
      expect(inspection.expReceipt(), inspection.diagnostic()).toMatchObject({ completion: "completed" });
      const inspectionRunId = only(inspection.expReceipt().createdRunIds, () => true, inspection.diagnostic());
      const inspectionAttempt = only(
        inspection.expEvalEvents(),
        (event) => event.evalId === "inspection",
        inspection.diagnostic(),
      );
      const inspectionLocator = withAt(inspectionAttempt.locator);

      const comparison = await niceeval.run(["exp", "main", "--rerun", "all", "--json"]);
      expect(comparison.exitCode, comparison.diagnostic()).toBe(0);
      const comparisonRunId = only(comparison.expReceipt().createdRunIds, () => true, comparison.diagnostic());
      const comparisonAttempt = only(
        comparison.expEvalEvents(),
        (event) => event.evalId === "inspection",
        comparison.diagnostic(),
      );
      const comparisonLocator = withAt(comparisonAttempt.locator);

      const alternate = await niceeval.run(["exp", "alternate", "--rerun", "all", "--json"]);
      expect(alternate.exitCode, alternate.diagnostic()).toBe(0);

      const executionTrace = await niceeval.run(["exp", "execution-trace", "--rerun", "all", "--json"]);
      expect(executionTrace.exitCode, executionTrace.diagnostic()).toBe(0);
      const executionLocator = withAt(only(executionTrace.expEvalEvents(), (event) => event.evalId === "execution-trace", executionTrace.diagnostic()).locator);

      const partialUsage = await niceeval.run(["exp", "partial-usage", "--rerun", "all", "--json"]);
      expect(partialUsage.expReceipt(), partialUsage.diagnostic()).toMatchObject({ completion: "completed" });

      let recallLocator = "";
      let toolLocator = "";
      let selectedRunId = "";
      for (const experimentId of ["classic/baseline", "classic/memory-a", "classic/incompatible"] as const) {
        const result = await niceeval.run(["exp", experimentId, "--rerun", "all", "--json"]);
        expect(result.expReceipt(), result.diagnostic()).toMatchObject({ completion: "completed" });
        if (experimentId === "classic/memory-a") {
          selectedRunId = only(result.expReceipt().createdRunIds, () => true, result.diagnostic());
          recallLocator = withAt(only(
            result.expEvalEvents(),
            (event) => event.evalId === "classic/recall-name",
            result.diagnostic(),
          ).locator);
          toolLocator = withAt(only(
            result.expEvalEvents(),
            (event) => event.evalId === "classic/tool-note",
            result.diagnostic(),
          ).locator);
        }
      }
      expect(recallLocator).toMatch(/^@[0-9A-Z]+$/u);
      expect(toolLocator).toMatch(/^@[0-9A-Z]+$/u);
      expect(selectedRunId).not.toBe("");

      const selectedView = niceeval.start([
        "view",
        "--run",
        selectedRunId,
        "--no-open",
        "--port",
        "0",
      ], { timeoutMs: 90_000 });
      try {
        const ready = await waitForViewReady(selectedView);
        await page.goto(expectLoopbackReadyUrl(ready.url).href);
        await expect(page.getByRole("heading", { name: "NiceEval Insight", exact: true })).toBeVisible();
        const selectedSummary = page.locator("summary.niceeval-table-hierarchy-summary").filter({
          hasText: /^classic\/memory-a /u,
        });
        await expect(selectedSummary).toHaveCount(1);
        await expect(selectedSummary).toBeVisible();
        await expect(page.locator("summary.niceeval-table-hierarchy-summary").filter({
          hasText: /^classic\/baseline /u,
        })).toHaveCount(0);
        await expect(page.locator("summary.niceeval-table-hierarchy-summary").filter({
          hasText: /^classic\/incompatible /u,
        })).toHaveCount(0);
      } finally {
        await page.goto("about:blank");
        await stopView(selectedView);
      }

      const view = niceeval.start([
        "view",
        "--no-open",
        "--port",
        "0",
      ], { timeoutMs: 90_000 });

      try {
        const ready = await waitForViewReady(view);
        const response = await page.goto(expectLoopbackReadyUrl(ready.url).href);
        expect(response?.status()).toBe(200);
        await expect(page.getByRole("heading", { name: "NiceEval Insight", exact: true })).toBeVisible();

        const header = page.getByRole("banner");
        const experimentSelector = header.getByRole("combobox", { name: "Experiments" });
        const languageSelector = header.getByRole("combobox", { name: "Language" });
        await expect(experimentSelector).toBeVisible();
        await expect(languageSelector).toBeVisible();
        const headerComboboxes = header.getByRole("combobox");
        await expect(headerComboboxes).toHaveCount(2);
        await expect(headerComboboxes.nth(0)).toHaveAccessibleName("Experiments");
        await expect(headerComboboxes.nth(1)).toHaveAccessibleName("Language");
        await expect(experimentSelector.getByRole("option")).toContainText([
          "named/classic",
          "singleton/alternate",
          "singleton/main",
          "singleton/partial-usage",
        ]);
        await experimentSelector.selectOption("/group/singleton/partial-usage");
        const partialUsageSummary = page.locator("summary.niceeval-table-hierarchy-summary").filter({
          hasText: /^partial-usage /u,
        });
        const partialUsageTokens = partialUsageSummary.locator(".niceeval-table-hierarchy-cell").nth(4);
        await expect(partialUsageTokens.locator(".niceeval-value")).toHaveText("12 tokens");
        await expect(partialUsageTokens.locator(".niceeval-coverage")).toHaveText("partial");
        await expect(partialUsageTokens.locator(".niceeval-coverage")).toHaveAttribute(
          "title",
          "This value is a known subtotal because some underlying observations are unavailable",
        );
        const partialUsageCost = partialUsageSummary.locator(".niceeval-table-hierarchy-cell").nth(5);
        await expect(partialUsageCost.locator(".niceeval-value")).toHaveText("$0.000001");
        await expect(partialUsageCost.locator(".niceeval-coverage")).toHaveText("partial");
        await expect(partialUsageCost.locator(".niceeval-cost-source")).toHaveText("reported + estimated");
        await partialUsageSummary.click();
        const partialUsageDetails = partialUsageSummary.locator("xpath=..");
        const partialUsageEval = partialUsageDetails.locator("summary.niceeval-table-hierarchy-summary").filter({
          hasText: /^usage-cost/u,
        });
        await expect(partialUsageEval.locator(".niceeval-table-hierarchy-cell").nth(4).locator(".niceeval-value")).toHaveText("12 tokens");
        await expect(partialUsageEval.locator(".niceeval-table-hierarchy-cell").nth(5).locator(".niceeval-value")).toHaveText("$0.000001");
        await expect(partialUsageEval.locator(".niceeval-table-hierarchy-cell").nth(5).locator(".niceeval-coverage")).toHaveText("partial");
        await partialUsageEval.click();
        const partialUsageAttempt = partialUsageEval.locator("xpath=..").locator(".niceeval-table-hierarchy-row").first();
        await expect(partialUsageAttempt.locator(".niceeval-table-hierarchy-cell").nth(4).locator(".niceeval-value")).toHaveText("12 tokens");
        await expect(partialUsageAttempt.locator(".niceeval-table-hierarchy-cell").nth(5).locator(".niceeval-value")).toHaveText("$0.000001");
        await expect(partialUsageAttempt.locator(".niceeval-table-hierarchy-cell").nth(5).locator(".niceeval-coverage")).toHaveText("partial");
        await partialUsageAttempt.getByRole("link", { name: /^@/u }).click();
        const externalUsage = page.getByRole("region", { name: "External call usage", exact: true });
        await expect(externalUsage).toContainText("1/2 calls fully costed");
        await externalUsage.getByText(/^Recorded calls/u).click();
        await expect(externalUsage).toContainText("vercel-ai-gateway.response");
        await externalUsage.getByText("Sealed pricing evidence", { exact: true }).click();
        await expect(externalUsage).toContainText("tokens-unknown");
        await page.getByRole("dialog").getByRole("button", { name: "Close", exact: true }).click();
        await experimentSelector.selectOption("/group/singleton/score-completeness");
        const scoreExperiment = page.locator("summary.niceeval-table-hierarchy-summary").filter({
          hasText: /^score-completeness \(\d+\/4\)/u,
        });
        const scoreTotal = scoreExperiment.locator(".niceeval-table-hierarchy-cell").last();
        await expect(scoreTotal.locator(".niceeval-value")).toHaveText("61 points");
        await expect(scoreTotal.locator(".niceeval-cell-detail")).toHaveText("Result coverage 2/4");
        await scoreExperiment.click();
        const scoreDetails = scoreExperiment.locator("xpath=..");
        for (const [name, expectedScore, expectedDetailScore] of [
          ["failed", "61 points", "61 pts"],
          ["zero", "0 points", "0 pts"],
        ] as const) {
          const evalSummary = scoreDetails.locator("summary.niceeval-table-hierarchy-summary").filter({
            hasText: new RegExp(`^score-completeness/${name}\\b`, "u"),
          });
          await expect(evalSummary.locator(".niceeval-table-hierarchy-cell").last().locator(".niceeval-value"))
            .toHaveText(expectedScore);
          await expect(evalSummary).toContainText("failed");
          await evalSummary.click();
          const attemptRow = evalSummary.locator("xpath=..").locator(".niceeval-table-hierarchy-row");
          await attemptRow.getByRole("link", { name: scoreLocators.get(`score-completeness/${name}`)!, exact: true }).click();
          const scoreDialog = page.getByRole("dialog");
          await expect(scoreDialog.locator(".niceeval-verdict-pill").first()).toHaveText("failed");
          const scoreKpi = scoreDialog.locator(".niceeval-kpi").filter({
            has: page.getByText("Score", { exact: true }),
          });
          await expect(scoreKpi.locator(".niceeval-kpi-value")).toHaveText(expectedDetailScore);
          await scoreDialog.getByRole("button", { name: "Close", exact: true }).click();
        }
        for (const name of ["partial", "unavailable"] as const) {
          const evalSummary = scoreDetails.locator("summary.niceeval-table-hierarchy-summary").filter({
            hasText: new RegExp(`^score-completeness/${name}\\b`, "u"),
          });
          await expect(evalSummary.locator(".niceeval-table-hierarchy-cell").last()).toContainText("unavailable");
          await evalSummary.click();
          await evalSummary.locator("xpath=..").getByRole("link", {
            name: scoreLocators.get(`score-completeness/${name}`)!, exact: true,
          }).click();
          const scoreDialog = page.getByRole("dialog");
          await expect(scoreDialog.locator(".niceeval-verdict-pill").first()).toHaveText("errored");
          await expect(scoreDialog.locator(".niceeval-kpi").filter({
            has: page.getByText("Score", { exact: true }),
          })).toHaveCount(0);
          await scoreDialog.getByRole("button", { name: "Close", exact: true }).click();
        }
        await experimentSelector.selectOption("/group/named/classic");
        await expect(page).toHaveURL(/#\/group\/named\/classic$/u);

        await languageSelector.selectOption("zh-CN");
        expect(new URL(page.url()).hash).toBe("#/group/named/classic");
        await expect(page.locator("html")).toHaveAttribute("lang", "zh-CN");
        await page.getByRole("combobox", { name: "实验" }).selectOption("/group/named/classic");
        await page.getByRole("combobox", { name: "语言" }).selectOption("en");

        const experimentSummary = page.locator("summary.niceeval-table-hierarchy-summary").filter({
          hasText: /^classic\/memory-a /u,
        });
        await expect(experimentSummary).toHaveCount(1);
        await experimentSummary.click();
        const experimentDetails = experimentSummary.locator("xpath=..");
        await expect(experimentDetails).toHaveAttribute("open", "");

        const evalGroupSummary = experimentDetails.locator("summary.niceeval-table-hierarchy-summary").filter({
          hasText: /^classic \(8 evals\)/u,
        });
        await expect(evalGroupSummary).toHaveCount(1);
        await evalGroupSummary.click();
        await expect(evalGroupSummary.locator("xpath=..")).toHaveAttribute("open", "");

        const recallSummary = experimentDetails.locator("summary.niceeval-table-hierarchy-summary").filter({
          hasText: /^recall-name/u,
        });
        await expect(recallSummary).toHaveCount(1);
        await recallSummary.click();
        await expect(recallSummary.locator("xpath=..")).toHaveAttribute("open", "");
        const recallAttempt = experimentDetails.getByRole("link", { name: recallLocator, exact: true });
        await expect(recallAttempt).toBeVisible();

        const scoreSummary = page.locator("summary.niceeval-table-hierarchy-summary").filter({
          hasText: /^classic\/incompatible /u,
        });
        await expect(scoreSummary.locator(".niceeval-table-hierarchy-cell").first()).toHaveText(
          "classic/incompatible (1/10)",
        );
        const scoreValue = scoreSummary.locator(".niceeval-table-hierarchy-cell").last().locator(".niceeval-value");
        await expect(scoreValue).toHaveCount(1);
        await expect(scoreValue).toHaveText("7 points");
        await expect(scoreSummary).not.toContainText("missed check");
        await expect(scoreSummary).not.toContainText("passed");
        await expect(scoreSummary.locator(".niceeval-coverage")).toHaveCount(0);
        const missingScore = experimentDetails.locator(".niceeval-row-placeholder").filter({
          hasText: /^score/u,
        });
        await expect(missingScore.locator(".niceeval-missing-reason")).toHaveText(
          "no result for current config",
        );
        await expect(missingScore.locator(".niceeval-cell-detail")).toHaveText(
          "niceeval exp classic/memory-a",
        );
        await expect(page.locator(".niceeval-value").filter({ hasText: /^0$/u })).toHaveCount(0);

        await testInfo.attach("snapshot-overview", {
          body: await page.screenshot({ fullPage: true }),
          contentType: "image/png",
        });

        const overviewHash = new URL(page.url()).hash;
        await recallAttempt.click({ noWaitAfter: true });
        const dialog = page.getByRole("dialog");
        await expect(dialog).toBeVisible();
        const overviewHeading = page.locator("main h1");
        await expect(overviewHeading).toHaveCount(1);
        await expect(overviewHeading).toHaveText("NiceEval Insight");
        await expect(overviewHeading).toBeVisible();
        const attemptSummaryLocator = dialog.locator(".niceeval-attempt-summary-locator");
        await expect(attemptSummaryLocator).toHaveCount(1);
        await expect(attemptSummaryLocator).toBeVisible();
        await expect(attemptSummaryLocator).toHaveText(recallLocator);
        await expect(experimentDetails).toHaveAttribute("open", "");
        await expect(evalGroupSummary.locator("xpath=..")).toHaveAttribute("open", "");
        await expect(recallSummary.locator("xpath=..")).toHaveAttribute("open", "");

        const assertionLine = dialog.locator("summary").filter({ hasText: "t.check(t.reply" }).first();
        await assertionLine.click();
        const rootMatch = dialog.getByLabel(/^and\(includes.+: matched$/u).first();
        await expect(rootMatch).toBeVisible();
        await rootMatch.click();
        const orMatch = dialog.getByLabel(/^or\(includes.+: matched$/u).first();
        await expect(orMatch).toBeVisible();
        await orMatch.click();
        const orNode = orMatch.locator("xpath=..");
        await expect(orNode.getByLabel('includes("RECALL_OK"): matched')).toBeVisible();
        await expect(orNode.getByLabel('includes("NEVER_PRESENT"): mismatched')).toBeVisible();
        const assertionDetail = assertionLine.locator("xpath=..").locator(":scope > .niceeval-source-line-detail");
        await expect(assertionDetail.getByText("Expected", { exact: true }).first()).toBeVisible();
        await expect(assertionDetail.getByText("Observed", { exact: true }).first()).toBeVisible();
        await expect(assertionDetail.getByText("Reason", { exact: true }).first()).toBeVisible();

        const copiedAttemptUrl = page.url();
        await dialog.getByRole("button", { name: "Close" }).click();
        await expect(dialog).not.toBeVisible();
        expect(new URL(page.url()).hash).toBe(overviewHash);
        await expect(experimentDetails).toHaveAttribute("open", "");

        await page.goForward();
        await expect(dialog).toBeVisible();
        await page.goBack();
        await expect(dialog).not.toBeVisible();
        await page.goForward();
        await expect(dialog).toBeVisible();
        await page.reload();
        expect(page.url()).toBe(copiedAttemptUrl);
        await expect(dialog).toBeVisible();

        const shared = await page.context().newPage();
        try {
          await shared.goto(copiedAttemptUrl);
          await expect(shared.getByRole("dialog")).toBeVisible();
          const sharedOverviewHeading = shared.locator("main h1");
          await expect(sharedOverviewHeading).toHaveCount(1);
          await expect(sharedOverviewHeading).toHaveText("NiceEval Insight");
          await expect(sharedOverviewHeading).toBeVisible();
          await shared.getByRole("button", { name: "Close" }).click();
          await expect(shared.getByRole("dialog")).not.toBeVisible();
          await expect(shared).toHaveURL(/#\/group\/named\/classic$/u);
        } finally {
          await shared.close();
        }

        await page.mouse.click(5, 5);
        await expect(dialog).not.toBeVisible();
        await expect(page).toHaveURL(/#\/group\/named\/classic$/u);

        const inspectionRunRoute = `/run/${encodeURIComponent(inspectionRunId)}`;
        const runPage = await page.context().newPage();
        try {
          await runPage.goto(new URL(`#${inspectionRunRoute}`, page.url()).href);
          const inspectionRunHeading = runPage.locator("main h2.niceeval-section-title").filter({
            hasText: `Run membership · ${inspectionRunId}`,
          });
          await expect(inspectionRunHeading).toHaveCount(1);
          await expect(inspectionRunHeading).toHaveText(`Run membership · ${inspectionRunId}`);
          await expect(inspectionRunHeading).toBeVisible();
          const inspectionRunAttempt = runPage.getByRole("link", { name: inspectionLocator, exact: true });
          await expect(inspectionRunAttempt).toBeVisible();
          await inspectionRunAttempt.click({ noWaitAfter: true });
          const runDialog = runPage.locator('[role="dialog"]');
          await expect(runDialog).toHaveCount(1);
          await expect(runDialog).toBeVisible();
          await expect(runDialog.locator(".niceeval-attempt-summary-locator")).toHaveText(inspectionLocator);
          await expect(inspectionRunHeading).toBeVisible();
          await runDialog.getByRole("button", { name: "Close" }).click();
          await expect(runDialog).not.toBeVisible();
          expect(new URL(runPage.url()).hash).toBe(`#${inspectionRunRoute}`);
          await expect(inspectionRunHeading).toBeVisible();
        } finally {
          await runPage.close();
        }

        const toolExperiment = page.locator("summary.niceeval-table-hierarchy-summary").filter({
          hasText: /^classic\/memory-a /u,
        });
        if (await toolExperiment.locator("xpath=..").getAttribute("open") === null) await toolExperiment.click();
        const toolGroup = toolExperiment.locator("xpath=..").locator("summary.niceeval-table-hierarchy-summary").filter({
          hasText: /^classic \(8 evals\)/u,
        });
        if (await toolGroup.locator("xpath=..").getAttribute("open") === null) await toolGroup.click();
        const toolEval = toolExperiment.locator("xpath=..").locator("summary.niceeval-table-hierarchy-summary").filter({
          hasText: /^tool-note/u,
        });
        if (await toolEval.locator("xpath=..").getAttribute("open") === null) await toolEval.click();
        const toolAttempt = toolExperiment.locator("xpath=..").getByRole("link", { name: toolLocator, exact: true });
        const toolHref = await toolAttempt.getAttribute("href");
        expect(toolHref).toMatch(/^#\/attempt\//u);
        await page.goto(new URL(toolHref!, page.url()).href);
        await expect(dialog).toBeVisible();

        const usageGrid = dialog.locator(".niceeval-usage-table");
        const usageCells = usageGrid.locator(":scope > .niceeval-grid-cell");
        await expect(usageCells).toHaveCount(5);
        const firstUsageRow = await usageCells.evaluateAll((cells) => cells.slice(0, 2).map((cell) => {
          const { x, y } = cell.getBoundingClientRect();
          return { x, y };
        }));
        expect(firstUsageRow[1]!.x).toBeGreaterThan(firstUsageRow[0]!.x);
        expect(Math.abs(firstUsageRow[1]!.y - firstUsageRow[0]!.y)).toBeLessThan(1);

        const sendLine = dialog.locator("details.niceeval-source-line--send").filter({
          hasText: 'const turn = await t.send("Write a memory note, then recall it.");',
        });
        await expect(sendLine).toHaveCount(1);
        await sendLine.locator(":scope > summary").click();
        const sendDetail = sendLine.locator(":scope > .niceeval-source-line-detail");
        await expect(sendDetail.getByText("Session log", { exact: true })).toBeVisible();

        const absenceAssertion = dialog.locator("details.niceeval-source-line > summary").filter({
          hasText: 'turn.notCalledTool("forbidden_state_tool")',
        });
        await absenceAssertion.click();
        const absenceDetail = absenceAssertion.locator("xpath=..").locator(":scope > .niceeval-source-line-detail");
        const absenceMatch = absenceDetail.getByLabel(
          'notCalledTool(toolMatch("forbidden_state_tool")): matched',
        );
        await absenceMatch.click();
        const structuredObserved = absenceDetail
          .getByRole("heading", { name: "Observed", exact: true })
          .locator("xpath=..");
        await expect(structuredObserved).toBeVisible();
        await expect(structuredObserved.locator("dt")).toHaveText(["kind", "outcome"]);
        await expect(structuredObserved).toContainText("boolean");
        await expect(structuredObserved).toContainText("matched");
        await expect(absenceDetail).not.toContainText("fields: label:");

        const toolAssertion = dialog.locator("details.niceeval-source-line > summary").filter({
          hasText: 'toolMatch("write_note").exactly(1)',
        });
        const toolAssertionDetails = toolAssertion.locator("xpath=..");
        if (await toolAssertionDetails.getAttribute("open") === null) await toolAssertion.click();
        const toolDetail = toolAssertionDetails.locator(":scope > .niceeval-source-line-detail");
        await expect(toolDetail).toBeVisible();
        const toolMatcher = toolDetail.getByLabel('toolMatch("write_note").exactly(1): mismatched');
        await toolMatcher.click();
        const toolFilter = toolDetail.getByRole("region", { name: "Tool call filter" });
        await expect(toolFilter).toBeVisible();
        await expect(toolFilter.getByText('exactly 1 × toolMatch("write_note")', { exact: true })).toBeVisible();
        const toolLedger = toolFilter.locator("details.niceeval-filter-ledger");
        await toolLedger.locator(":scope > summary").click();
        await expect(toolLedger.locator(".niceeval-filter-row").first()).toBeVisible();

        const eventAssertion = dialog.locator("details.niceeval-source-line > summary").filter({
          hasText: 'turn.check(turn.eventOccurrences, eventMatch("message"',
        });
        const eventAssertionDetails = eventAssertion.locator("xpath=..");
        if (await eventAssertionDetails.getAttribute("open") === null) await eventAssertion.click();
        const eventDetail = eventAssertionDetails.locator(":scope > .niceeval-source-line-detail");
        await expect(eventDetail).toBeVisible();
        await eventDetail.getByLabel("Assistant message event: matched").click();
        await expect(eventDetail.getByRole("region", { name: "Event filter" })).toContainText(
          "exactly 1 × eventMatch(message)",
        );

        const commandAssertion = dialog.locator("details.niceeval-source-line > summary").filter({ hasText: "t.check({" });
        const commandAssertionDetails = commandAssertion.locator("xpath=..");
        if (await commandAssertionDetails.getAttribute("open") === null) await commandAssertion.click();
        const commandDetail = commandAssertionDetails.locator(":scope > .niceeval-source-line-detail");
        await expect(commandDetail).toBeVisible();
        await commandDetail.getByLabel("commandSucceeded(): matched").click();
        const commandResult = commandDetail.getByRole("heading", { name: "Command result" }).locator("xpath=..");
        await expect(commandResult).toBeVisible();
        await expect(commandResult.getByText("pnpm test", { exact: true })).toBeVisible();
        await expect(commandResult.getByText("Exit code 0", { exact: true })).toBeVisible();
        await expect(commandResult.getByText("PASS src/example.test.ts", { exact: true })).not.toBeVisible();

        const trajectory = sendDetail.getByRole("region", { name: "Trajectory timeline" });
        await expect(trajectory).toBeVisible();
        await expect(trajectory.getByText("Input / User", { exact: true })).toBeVisible();
        await expect(trajectory.getByText("Model / Assistant", { exact: true })).toBeVisible();
        await expect(trajectory.getByText("Tools / Tool", { exact: true })).toBeVisible();
        const search = sendDetail.getByRole("searchbox", { name: "Search trajectory" });
        await expect(search).toBeVisible();
        const toolOccurrence = sendDetail.getByRole("button", { name: /^tool: command_execution\b/i }).first();
        await toolOccurrence.click();
        await expect(toolOccurrence).toHaveAttribute("aria-expanded", "true");
        const toolPreview = toolOccurrence
          .locator("xpath=ancestor::article[1]")
          .getByRole("tabpanel", { name: "Preview" });
        await expect(toolPreview).toBeVisible();
        await expect(toolPreview.getByText("wrote memory-note.txt", { exact: false })).toBeVisible();
        const trajectoryControls = sendDetail.getByRole("toolbar", { name: "Trajectory controls" });
        await trajectoryControls.getByRole("button", { name: "Calls 1", exact: true }).click();
        await trajectoryControls.getByRole("button", { name: "Turns 1", exact: true }).click();
        await search.fill("RECALL_OK");
        await expect(sendDetail.getByRole("button", { name: /^assistant:.*RECALL_OK/i }).first()).toBeVisible();
        await expect(dialog.getByText("turns", { exact: true })).toBeVisible();
        await expect(dialog.getByText("tool calls", { exact: true })).toBeVisible();
        await expect(dialog.getByText(/Execution timeline/u).first()).toBeVisible();
        const calloutSummary = dialog.getByText("2 groups · 2 warnings", { exact: true });
        await expect(calloutSummary).toBeVisible();
        const callouts = calloutSummary.locator("xpath=..");
        await calloutSummary.click();
        await expect(callouts).toHaveAttribute("open", "");
        await expect(callouts.getByText(
          "file-changes-not-recorded: File changes collection was not recorded for this Attempt.",
          { exact: true },
        )).toBeVisible();

        await testInfo.attach("snapshot-attempt", {
          body: await page.screenshot({ fullPage: true }),
          contentType: "image/png",
        });

        await dialog.getByRole("button", { name: "Close" }).click();
        await experimentSelector.selectOption("/group/singleton/execution-trace");
        const executionSummary = page.locator("summary.niceeval-table-hierarchy-summary").filter({ hasText: /^execution-trace \(1\/1\)/u });
        await executionSummary.click();
        const executionDetails = executionSummary.locator("xpath=..");
        await executionDetails.locator("summary.niceeval-table-hierarchy-summary").filter({ hasText: /^execution-trace/u }).nth(1).click();
        await executionDetails.getByRole("link", { name: executionLocator, exact: true }).click();
        const executionRegion = page.getByRole("dialog").getByRole("region", { name: "Execution events", exact: true });
        await expect(executionRegion).toBeVisible();
        await expect(executionRegion).not.toContainText("sealed-evidence-browser-sentinel");
        await executionRegion.getByRole("button", { name: "Courier reached the observed destination", exact: true }).click();
        await expect(executionRegion).toContainText("sealed-evidence-browser-sentinel");
        await expect(executionRegion).toContainText("/event");
        await executionRegion.getByRole("button", { name: "Open evidence", exact: true }).last().click();
        await expect(executionRegion).toContainText("SHA-256");
        await expect(executionRegion).toContainText("sealed-evidence-browser-sentinel");
        await page.getByRole("dialog").getByRole("button", { name: "Close" }).click();
        await experimentSelector.selectOption("/group/singleton/main");
        await expect(page).toHaveURL(/#\/group\/singleton\/main$/u);
        const frozenOverviewText = await page.locator(".niceeval-view-report-slot").first().innerText();
        const singletonSummary = page.locator("summary.niceeval-table-hierarchy-summary").filter({
          hasText: /^main \(1\/1\)/u,
        });
        await expect(singletonSummary).toHaveCount(1);
        await singletonSummary.click();
        const singletonDetails = singletonSummary.locator("xpath=..");
        await expect(singletonDetails).toHaveAttribute("open", "");
        const inspectionSummary = singletonDetails.locator("summary.niceeval-table-hierarchy-summary").filter({
          hasText: /^inspection/u,
        });
        await expect(inspectionSummary).toHaveCount(1);
        await inspectionSummary.click();
        const inspectionDetails = inspectionSummary.locator("xpath=..");
        await expect(inspectionDetails).toHaveAttribute("open", "");
        await expect(inspectionDetails.getByRole("link", { name: comparisonLocator, exact: true })).toBeVisible();
        await expect(inspectionDetails.getByRole("link", { name: inspectionLocator, exact: true })).toHaveCount(0);

        const later = await niceeval.run(["exp", "main", "--rerun", "all", "--json"]);
        expect(later.exitCode, later.diagnostic()).toBe(0);
        const laterRunId = only(later.expReceipt().createdRunIds, () => true, later.diagnostic());
        await page.reload();
        await expect(page.getByRole("heading", { name: "NiceEval Insight", exact: true })).toBeVisible();
        const reloadedReport = page.locator(".niceeval-view-report-slot").first();
        await expect(reloadedReport.getByRole("status")).toHaveCount(0);
        expect(await reloadedReport.innerText()).toBe(frozenOverviewText);
        await expect(page.getByRole("button", { name: /refresh/i })).toHaveCount(1);
        expect(laterRunId).not.toBe(inspectionRunId);
        expect(comparisonRunId).not.toBe(inspectionRunId);
        expect(pageErrors).toEqual([]);
        expect(consoleErrors).toEqual([]);
        expect(failedResponses).toEqual([]);
      } finally {
        await stopView(view);
      }

    },
  );
});

function withAt(locator: string): string {
  return locator.startsWith("@") ? locator : `@${locator}`;
}

async function stopView(view: ProcessHandle): Promise<void> {
  if (!view.settledExit) expect(view.signal("SIGTERM")).toBe(true);
  const closed = await view.done;
  expect(closed.exitCode, closed.diagnostic()).toBe(0);
  await view.dispose();
}

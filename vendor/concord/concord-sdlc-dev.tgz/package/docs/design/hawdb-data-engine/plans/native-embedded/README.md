# native-embedded

## Problem

统一缓存与检索引擎必须保持本地事实和可安装性。

## Limits

| Limit | Status | Mechanism or gap | Evidence |
| --- | --- | --- | --- |
| [L1](../../LIMITS.md#l1-source-ownership) | satisfied | 机制与约束见本页 | [研究依据](../../../../research/hawdb-integration/README.md) |
| [L2](../../LIMITS.md#l2-lifecycle-and-safety) | satisfied | 机制与约束见本页 | [研究依据](../../../../research/hawdb-integration/README.md) |
| [L3](../../LIMITS.md#l3-packaging-and-implementation) | satisfied | 机制与约束见本页 | [研究依据](../../../../research/hawdb-integration/README.md) |
| [L4](../../LIMITS.md#l4-bounded-behavior) | satisfied | 机制与约束见本页 | [研究依据](../../../../research/hawdb-integration/README.md) |

## Goals

| Goal | Status | Mechanism or gap | Evidence |
| --- | --- | --- | --- |
| [G1](../../GOALS.md#g1-unified-engine) | satisfied | 机制与约束见本页 | [研究依据](../../../../research/hawdb-integration/README.md) |
| [G2](../../GOALS.md#g2-current-projections) | satisfied | 机制与约束见本页 | [研究依据](../../../../research/hawdb-integration/README.md) |
| [G3](../../GOALS.md#g3-independent-installation) | satisfied | 机制与约束见本页 | [研究依据](../../../../research/hawdb-integration/README.md) |

## Mechanism

Node 通过窄 N-API bridge 调用固定 revision 的 HawDB 公开 facade。关系缓存使用参数化 SQL；参数不拼进语句。领域决策、严格 Schema、源摘要和发布授权由 TypeScript/Effect 维护。原生边界限于嵌入式引擎、类型转换、预算和句柄生命周期。

Git-private 的版本化 HawDB 目录容纳注解、代码、配置及远端观察命名空间。持久句柄在短快照内按需打开和复用，在来源快照结束前关闭，不跨网络请求或 Web 空闲时间持有。只读发现不能因为命名空间缺失创建表。缺失、损坏和占用分别沿用具名诊断与当前来源回退，不静默使用过期数据。

短期文档解析、代码解析及不可变 Git 测试基线使用 HawDB 内存实例。纯解析入口不依赖 Repository 或磁盘目录；namespace 区分数据，源摘要与解析器身份区分代次。缓存有条目数及字节上限，不另存 Map payload 缓存。批量加载采用有界批量读取/写入；一次请求的临时结果集合不构成第二个缓存。

Memory/Issue 的 index 和 recall 继续核对当前目录和源字节；共享的解析投影改用 HawDB。现有子串查询及排序不被伪装为 BM25 或语义检索。Trace 的关系有效性、权限和 fixed 仍从当前权威输入推导。

清理由原生目录所有权保护，须区分活动句柄和损坏库。打开失败本身不代表可删除；原生所有权锁授权清理。只清理受管 HawDB 目录内的缓存内容，保留目录与所有权锁 inode，不删除 evidence/journal。预览列出清理范围与原生产物可用性，执行时重新验证所有权。远端缓存丢失后只有显式刷新可以重新获得观察，本地已捕获 Issue 保留。

原生依赖、Rust toolchain 与 Cargo lock 精确固定。构建编排保持严格 TypeScript/Effect；c-005 与 AGENTS 的窄原生例外在采用前显式修订。发行流程先在 Ubuntu 与 Apple Silicon macOS 构建 native 产物，再装入同一个 tgz，核验完整目标集合、版本与摘要后发布；自动流水线不执行测试或真实安装，安装验证保留为手动入口。消费者不需要 Rust、全局 HawDB 或安装脚本。缺少或错误的平台产物返回具名错误，不隐藏切回 SQLite。

## Evidence and tradeoffs

[研究与探针证据](../../../../research/hawdb-integration/README.md)确认 Node 24 的真实调用、普通事务回滚、持久重开和内存命名空间能力。stripped release 原型约 19 MiB；本机 Nix 构建不能作为通用 Linux 发布物。探针不证明进程崩溃恢复、生产安全、跨平台兼容或完整 Concord 延迟。

HawDB 统一引擎会增加原生包体、构建矩阵、查询与序列化成本。相同 1000 篇合成文档的热解析投影由旧 Map 约 4.6 ms 增至朴素 HawDB 约 110 ms；有界批量原型约 33 ms。数字只说明优化方向，实际 CLI/Web 的源检查、Schema 解码、预算清理和资源释放必须单独验收。

## Open modes and ownership

构造配置读取、feedback 观察和 status 仅 existing-only/read-only 打开；缺目录、格式标记、ownership 文件或表时不补写，回源或报告 empty/unavailable。dry-run 不创建持久引擎文件。来源读取不取得 publication lease，数据库目录仍由引擎所有权协议保护。

最外层 snapshot 拥有按需句柄，嵌套调用只复用。只读句柄需要写入时，关闭后重新以写模式打开，并重新竞争引擎所有权；没有跨调用逃逸的 native transaction。持久句柄在来源快照结束时释放；存在独占提交时，数据库先于提交 owner 释放。纯解析的无磁盘内存句柄属于进程，关闭或失效后允许重建。

clear 先关闭本进程受管持久句柄，通过 native guard 对固定 revision 的 owner.hawdb.lock 执行非截断 File::try_lock。只在取得锁后删缓存数据，保留目录和同一个锁 inode。WouldBlock、权限、I/O 或未知错误均拒绝删除；损坏 manifest 不影响独立取锁。owner-only 目录视为空。缺锁文件只在明确写入/clear 且路径已验证时创建，读取与 dry-run 不补建。非目录缓存根、symlink、硬链接锁、特殊文件或前后 inode 不符均拒绝。

该锁适配是对固定 revision 协议的显式窄依赖，不是 HawDBError 字符串推断，也不绕过公开数据 API。互斥保证覆盖遵守 Concord 协调协议和已持有 HawDB 文件锁的进程；不宣称抵抗任意外部路径替换。

## Resource budgets

预算按序列化 UTF-8 字节计入 namespace、key、source envelope 和 payload，不把字符数当字节数。以下为固定初始上限，超过上限返回具名失败或按原有语义回源，不返回截断成功。

| Namespace | Entry limit | Byte limit |
| --- | ---: | ---: |
| 文档与静态配置短期解析合计 | 10000 | 16 MiB |
| 代码短期解析 | 10000 | 16 MiB |
| Git baseline | 128 | 4 MiB |
| annotation_cache | 64 | 24 MiB |
| code_cache | 20000 | 32 MiB |
| config_cache | 128 | 8 MiB |
| feedback_cache | 10000 | 32 MiB |

内存缓存总逻辑预算 36 MiB，持久缓存总逻辑预算 96 MiB。query_cache 命名空间最多 64 行、16 MiB，并与其它命名空间共享总预算。淘汰采用可解释的插入顺序；新批次自身超过预算则整批拒绝，不能提交部分结果。短期内部代次按累计写入/删除量有界重建，避免只删除逻辑行而无限累积引擎 tombstone；重建期间旧/新实例合计最多两份既定逻辑预算。

文档解析分配 9872 条、15 MiB；静态配置解析分配 128 条、1 MiB。二者使用各自进程期内存句柄和解析器身份，合计保持文档解析预算。配置命中只复用严格解码的值，每次操作仍读取配置原文并执行仓库安全与协调检查。

桥接单条输入最多 8 MiB，每次批量最多 1000 条且总输入最多 16 MiB。native 查询最多 20000 行、64 MiB payload；大于该预算的完整 namespace 读取须分批且仍受 namespace 总预算约束。持久目录的总字节数和条目数量不构成打开、状态检查或清理的拒绝条件。目录检查逐项校验路径、文件类型和链接；清理在完整检查与原生所有权守卫内执行，保留锁 inode。物理文件增长不使缓存失去清理入口。

HawDB 的 WAL 上限：max_wal_replay_entries=100000、max_wal_replay_bytes=128 MiB、max_wal_record_bytes=64 MiB、max_wal_batch_operations=50000。checkpoint 的 encoded 上限为 256 MiB，decoded 上限为 512 MiB。

segment cache 为 16 MiB，graph manifest 为 8 MiB，out-of-core delta 不超过 16 MiB。严格恢复，不自动修复坏 WAL；不用上游 TiB 级默认解码额度。

达到 4 MiB WAL 增量或累计 32 个写事务后执行公开 checkpoint，失败使缓存不可用并保留现场；只读不 checkpoint。内存表定期重建与持久 checkpoint 都是缓存维护，不改来源。

同批重复 feedback identity 按输入顺序与本批已合并值继续比较；保留单调时间戳和同版本冲突语义，最后一个 putBatch 原子发布。

## Release identity

发行产物集合固定为 linux-x64-glibc 与 darwin-arm64，后者 deployment target 为 macOS 15.0，符合 Ubuntu 24.04 与 Apple Silicon macOS 15 构建基线。native manifest 绑定同一桥接源码、Cargo lock、ABI、HawDB revision 和二进制摘要。构建先清空 dist，再汇入完整平台集合；后续 host build 不能擦掉其它目标。只 pack 一次，各渠道验证同一个 SHA-256。缺项或不匹配阻断发行，本机 Nix 产物不进入通用发行物。

## Adoption conditions

所有权 guard、打开模式、资源预算、窄原生边界和发行身份分别由本页的 Open modes and ownership、Resource budgets、Release identity，以及宪法 C-001/C-005 和架构契约约束。

同进程与跨进程互斥、损坏 manifest 的受锁清理、同一锁 inode 保留和空库重开都属于验收范围。预算字段须匹配固定 revision 的公开 DatabaseConfig，不采用 TiB 级默认值。生产路径守卫、崩溃恢复、缓存语义、请求延迟及打包消费者也须验收。

clear 的进一步边界：目录不存在时无操作；只有完整预检为 owner-only 的目录才报告 empty，未知内容不归为空。删除并不原子化；中断或部分失败保留现场，后续显式 clear 可重新取 guard 继续，不自动调用数据库恢复。原型仅覆盖同进程双向互斥及跨进程 guard 阻止 HawDB，反方向和明确 busy 类别由生产测试补齐。
